import React from "react"
import HeadTitle from "../../Common/HeadTitle/HeadTitle"
import AllItem from "./AllItem"

const Destinations = () => {
  return (
    <div>
      <HeadTitle />
      <AllItem />
    </div>
  )
}

export default Destinations

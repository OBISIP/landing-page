const Wdata = [
  {
    id: 1,
    cover: "/images/works/work-1.png",
    title: "Search Multiple Destinations",
    desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum.",
  },
  {
    id: 1,
    cover: "/images/works/work-3.png",
    title: "Find the Lowest Hotel Prices",
    desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum.",
  },
  {
    id: 1,
    cover: "/images/works/work-2.png",
    title: "Find the Right Hotel for You",
    desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum.",
  },
]
export default Wdata

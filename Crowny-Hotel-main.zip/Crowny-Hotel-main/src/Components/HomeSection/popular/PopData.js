const PopularData = [
  {
    id: 1,
    image: "images/popular1.jpg",
    country: "Italy",
    name: "Hotel Valle",
    price: "$300.00",
  },
  {
    id: 2,
    image: "images/popular2.jpg",
    country: "Mexico",
    name: "Hotel Las Trojes",
    price: "$400.00",
  },
  {
    id: 3,
    image: "images/popular3.jpg",
    country: "United States",
    name: "Rosen Shingle Creek",
    price: "$500.00",
  },
  {
    id: 4,
    image: "images/popular4.jpg",
    country: "Thailand",
    name: "Ansan Hotel",
    price: "$100.00",
  },
  {
    id: 5,
    image: "images/popular5.jpg",
    country: "Vietnam",
    name: "Fawlty Tower",
    price: "$200.00",
  },
  {
    id: 6,
    image: "images/popular2.jpg",
    country: "Mexico",
    name: "Hotel Las Trojes",
    price: "$400.00",
  },
  {
    id: 7,
    image: "images/popular3.jpg",
    country: "United States",
    name: "Rosen Shingle Creek",
    price: "$500.00",
  },
  {
    id: 8,
    image: "images/popular4.jpg",
    country: "Thailand",
    name: "Ansan Hotel",
    price: "$100.00",
  },
]

export default PopularData

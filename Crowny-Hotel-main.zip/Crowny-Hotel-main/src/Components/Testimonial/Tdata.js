const Tdata = [
  {
    id: 1,
    desc: "Lorem ipsum dolor sit amet consectetur ipiscing elit amet consectetur piscing elit consectetur adipiscing elit sed et eletum. orem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum nulla eu placerat felis etiam tincidunt orci lacus id varius dolor fermum sit amet.",
    name: "KEVIN MARTHIN",
    profile: "/images/profile/profile1.jpg",
    post: "Developer",
  },
  {
    id: 2,
    desc: "Lorem ipsum dolor sit amet consectetur ipiscing elit amet consectetur piscing elit consectetur adipiscing elit sed et eletum. orem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum nulla eu placerat felis etiam tincidunt orci lacus id varius dolor fermum sit amet.",
    name: "JOE GABRIEL",
    profile: "/images/profile/profile2.jpg",
    post: "Designer",
  },
  {
    id: 3,
    desc: "Lorem ipsum dolor sit amet consectetur ipiscing elit amet consectetur piscing elit consectetur adipiscing elit sed et eletum. orem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum nulla eu placerat felis etiam tincidunt orci lacus id varius dolor fermum sit amet.",
    name: "JOIN MANSOOR",
    profile: "/images/profile/profile3.jpg",
    post: "Support-Marketing",
  },
  {
    id: 4,
    desc: "Lorem ipsum dolor sit amet consectetur ipiscing elit amet consectetur piscing elit consectetur adipiscing elit sed et eletum. orem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum nulla eu placerat felis etiam tincidunt orci lacus id varius dolor fermum sit amet.",
    name: "SUSAN DAY",
    profile: "/images/profile/profile4.jpg",
    post: "CEO",
  },
  {
    id: 5,
    desc: "Lorem ipsum dolor sit amet consectetur ipiscing elit amet consectetur piscing elit consectetur adipiscing elit sed et eletum. orem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum nulla eu placerat felis etiam tincidunt orci lacus id varius dolor fermum sit amet.",
    name: "MICHAEL DAVID",
    profile: "/images/profile/profile5.jpg",
    post: "Consultant",
  },
  {
    id: 6,
    desc: "Lorem ipsum dolor sit amet consectetur ipiscing elit amet consectetur piscing elit consectetur adipiscing elit sed et eletum. orem ipsum dolor sit amet consectetur adipiscing elit amet consectetur piscing elit amet consectetur adipiscing elit sed et eletum nulla eu placerat felis etiam tincidunt orci lacus id varius dolor fermum sit amet.",
    name: "MEGAN MILLER",
    profile: "/images/profile/profile6.jpg",
    post: "Founder",
  },
]

export default Tdata
